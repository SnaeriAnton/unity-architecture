using Contracts;
using UniRx;

namespace Game
{
    public class PlayerInputController
    {
        private readonly CompositeDisposable _disposable = new();
        private readonly PlayerMovement _movement;
        private readonly IInput _input;

        public PlayerInputController(PlayerMovement movement, IInput input)
        {
            _input = input;
            _movement = movement;
        }

        public void Enable()  => _input.OnAxis.Subscribe(_movement.OnAxis).AddTo(_disposable);
        public void Disable() => _disposable.Dispose();
    }
}
