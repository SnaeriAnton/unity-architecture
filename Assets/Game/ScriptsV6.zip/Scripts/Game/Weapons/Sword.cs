using UnityEngine;

namespace Game
{
    public class Sword : MonoBehaviour
    {
        [SerializeField] private WeaponHitboxEcsLink _link;
        
        private LeoWeaponHitboxApi _leoWeaponHitboxApi;
        
        public void Init(LeoWeaponHitboxApi leoWeaponHitboxApi, float damage)
        {
            _leoWeaponHitboxApi = leoWeaponHitboxApi;

            if (!_link.IsRegistered)
            {
                int entity = _leoWeaponHitboxApi.RegisterWeaponHitbox(transform, damage);
                _link.Bind(entity);
            }
            else
            {
                _leoWeaponHitboxApi.RequestSetWeaponHitboxDamage(_link.Entity, damage);
            }
        }
        
        public void ResetEcsLink() => _link.Clear();
        
        private void OnTriggerEnter2D(Collider2D other)
        {
            if (!other.TryGetComponent(out EnemyEcsLink enemyLink)) return;
            if (!enemyLink.IsRegistered) return;
            if (!_link.IsRegistered) return;

            _leoWeaponHitboxApi.RequestWeaponHitboxHitEnemy(_link.Entity, enemyLink.Entity);
        }
    }
}
