using UnityEngine;
using Core.Pool;

namespace Game
{
    public abstract class Weapon : MonoBehaviour
    {
        protected PoolManager _poolManager;
        protected WeaponStats _stats;
        protected LeoProjectileApi _leoProjectileApi;
        protected LeoProjectileWeaponApi _leoProjectileWeaponApi;
        protected LeoWeaponHitboxApi _leoWeaponHitboxApi;
        protected LeoOrbitWeaponApi _leoOrbitWeaponApi;

        public virtual void Construct(PoolManager poolManager, LeoProjectileApi leoProjectileApi, LeoProjectileWeaponApi leoProjectileWeaponApi, LeoWeaponHitboxApi leoWeaponHitboxApi, LeoOrbitWeaponApi leoOrbitWeaponApi)
        {
            _poolManager = poolManager;
            _leoProjectileApi = leoProjectileApi;
            _leoProjectileWeaponApi = leoProjectileWeaponApi;
            _leoWeaponHitboxApi = leoWeaponHitboxApi;
            _leoOrbitWeaponApi = leoOrbitWeaponApi;
        }

        public virtual void UpdateValues() { }

        public virtual void SetStats(WeaponStats stats)
        {
            _stats = stats;
            gameObject.SetActive(true);
        }

        public virtual void Reset()
        {
            _stats = default;
            gameObject.SetActive(false);
        }
    }
}