using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Core.UI;
using ExtensionSystems;
using UniRx;

namespace Game
{
    public class UpgradeWindowView : Window
    {
        private readonly Dictionary<Weapons, UpgradeButtonView> _buttonViews = new();
        private readonly CompositeDisposable _disposable = new();

        [SerializeField] private Button _closeButton;
        [SerializeField] private TextMeshProUGUI _coinsText;
        [SerializeField] private TextMeshProUGUI _crystalText;

        private UpgradeWindowViewModel _viewModel;

        [field: SerializeField] public RectTransform ButtonsContainer { get; private set; }
        [field: SerializeField] public UpgradeButtonView UpgradeButtonViewTemplate { get; private set; }

        public void Bind(UpgradeWindowViewModel viewModel)
        {
            _viewModel = viewModel;

            _closeButton.onClick.AddListener(OnCloseWindow);
            _viewModel.Coins.Subscribe(RenderCoin).AddTo(_disposable);
            _viewModel.Crystals.Subscribe(RenderCrystals).AddTo(_disposable);
            _viewModel.Buttons.ForEach(v => CreateButton(v.Key, v.Value));
            _viewModel.Buttons.ObserveReplace().Subscribe(x => _buttonViews[x.Key].Bind(x.NewValue)).AddTo(_disposable);
        }

        public void Unbind()
        {
            _buttonViews.Values.ForEach(b => b.Unbind());
            _closeButton.onClick.RemoveListener(OnCloseWindow);
            _disposable.Dispose();
            _viewModel = null;
        }

        private void CreateButton(Weapons key, UpgradeButtonViewModel vm)
        {
            if (_buttonViews.ContainsKey(key))
            {
                _buttonViews[key].Bind(vm);
                return;
            }

            UpgradeButtonView view = Instantiate(UpgradeButtonViewTemplate, ButtonsContainer);
            view.Bind(vm);
            _buttonViews[key] = view;
        }

        private void RenderCoin(int coins) => _coinsText.text = coins.ToString();
        private void RenderCrystals(int crystals) => _crystalText.text = crystals.ToString();
        private void OnCloseWindow() => _viewModel?.CloseCommand.Execute();
    }
}