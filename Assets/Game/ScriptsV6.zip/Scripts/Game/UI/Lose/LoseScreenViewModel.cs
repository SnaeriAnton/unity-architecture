using System;
using UniRx;

namespace Game
{
    public class LoseScreenViewModel
    {
        private readonly CompositeDisposable _disposable = new();
        public ReactiveCommand StartGameCommand { get; } = new();

        public LoseScreenViewModel(Action startGameAction) => StartGameCommand.Subscribe(_ => startGameAction()).AddTo(_disposable);

        public void Dispose() => _disposable.Dispose();
    }
}