using UnityEngine;
using UniRx;

namespace Game
{
    public class EnemyViewModel
    {
        protected readonly EnemyModel _model;

        private readonly CompositeDisposable _disposable = new();
        private readonly ReactiveProperty<Vector3> _position;
        private readonly ReactiveProperty<bool> _isDead;

        public EnemyViewModel(EnemyModel model)
        {
            _model = model;

            _isDead = new(false);

            _model.OnDie.Subscribe(_ => Die()).AddTo(_disposable);
        }

        public IReadOnlyReactiveProperty<Vector3> Position => _model.Position;
        public IReadOnlyReactiveProperty<bool> IsDead => _isDead;

        public void Dispose() => _disposable.Dispose();
        public void SetPosition(Vector3 position) => _position.Value = position;

        private void Die()
        {
            _isDead.Value = true;
            Dispose();
        }
    }
}