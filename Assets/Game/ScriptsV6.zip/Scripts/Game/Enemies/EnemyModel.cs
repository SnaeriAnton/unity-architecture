using System;
using UniRx;
using UnityEngine;

namespace Game
{
    public class EnemyModel
    {
        private readonly Subject<Unit> _onDie = new();
        private readonly ReactiveProperty<Vector3> _position;
        
        private float _health;

        public EnemyModel(Stats stats)
        {
            Stats = stats;
            _health = Stats.Health;
        }

        public IReadOnlyReactiveProperty<Vector3> Position => _position;
        public Stats Stats { get; }

        public IObservable<Unit> OnDie => _onDie;

        public void SetPosition(Vector3 pos) => _position.Value = pos;
        
        public void TakeDamage(float damage)
        {
            if (_health <= 0) return;
            
            _health -= damage;

            if (_health <= 0)
                _onDie.OnNext(Unit.Default);
        }
    }
}