using UnityEngine;
using Object = UnityEngine.Object;
using Core.Pool;

namespace Game
{
    public class Factory
    {
        private readonly PoolManager _poolManager;
        private readonly Transform _playerTransform;
        private readonly LeoProjectileApi _leoProjectileApi;
        private readonly LeoProjectileWeaponApi _leoProjectileWeaponApi;
        private readonly LeoWeaponHitboxApi _leoWeaponHitboxApi;
        private readonly LeoOrbitWeaponApi _leoOrbitWeaponApi;
        private readonly LeoAxeApi _leoAxeApi;
        private readonly LeoEnemyApi _leoEnemyApi;

        public Factory(PoolManager poolManager, Transform playerTransform, LeoProjectileApi leoProjectileApi, LeoProjectileWeaponApi leoProjectileWeaponApi, LeoWeaponHitboxApi leoWeaponHitboxApi, LeoOrbitWeaponApi leoOrbitWeaponApi, LeoAxeApi leoAxeApi, LeoEnemyApi leoEnemyApi)
        {
            _poolManager = poolManager;
            _playerTransform = playerTransform;
            _leoProjectileApi = leoProjectileApi;
            _leoProjectileWeaponApi = leoProjectileWeaponApi;
            _leoWeaponHitboxApi = leoWeaponHitboxApi;
            _leoOrbitWeaponApi = leoOrbitWeaponApi;
            _leoAxeApi = leoAxeApi;
            _leoEnemyApi = leoEnemyApi;
        }

        public Weapon CreateWeapon(Weapon template, Transform parent)
        {
            Weapon weapon = Object.Instantiate(template, parent);
            weapon.Construct(_poolManager, _leoProjectileApi, _leoProjectileWeaponApi, _leoWeaponHitboxApi, _leoOrbitWeaponApi);
            return weapon;
        }

        public EnemyBase SpawnEnemy(EnemyBase prefab, Vector3 pos)
        {
            EnemyBase enemy = _poolManager.Spawn(prefab, pos, Quaternion.identity);
            enemy.Construct(_playerTransform, _poolManager, _leoAxeApi, _leoEnemyApi);
            int enemyEntity = _leoEnemyApi.RegisterEnemy(enemy, enemy.transform, enemy.Speed, enemy.Health, enemy.Damage, enemy.AttackCooldown);

            enemy.GetComponent<EnemyEcsLink>().Bind(enemyEntity);
            enemy.SetupEcs(enemyEntity);
            return enemy;
        }
    }
}