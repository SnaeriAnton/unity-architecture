using System.Collections.Generic;
using UnityEngine;
using Core.InputSystem;
using Core.Pool;
using Game;

namespace Core
{
    public class GameComposer : MonoBehaviour
    {
        [SerializeField] private List<WeaponLevelUpsData> _weaponLevelUpsData;
        [SerializeField] private PlayerLevelUpsData _playerLevelUpsData;
        [SerializeField] private UIRoot _uiRoot;
        [SerializeField] private Border _border;
        [SerializeField] private GeneratorData _generatorData;
        [SerializeField] private ProgressConfig _config;
        [SerializeField] private GameConfig _gameConfig;
        [SerializeField] private InputRoot _inputRoot;
        [SerializeField] private PlayerPickupTrigger _pickupTrigger;
        [SerializeField] private PlayerDeathView _playerDeathView;
        [SerializeField] private PlayerAuthoring _playerAuthoring;

        private UpgradeSystem _upgradeSystem;
        private GameUiBridge _gameUiBridge;
        private LeoEcsInstaller _leoEcsInstaller;

        private bool IsMobile => Application.isMobilePlatform;

        public void StartGame()
        {
            Compose();
            Initialization();
        }

        private void Update() => _leoEcsInstaller?.Run();

        private void OnDestroy() => Dispose();
        private void Dispose() => _leoEcsInstaller?.Dispose();

        private void Compose()
        {
            _inputRoot.Construct(IsMobile);
            
            _leoEcsInstaller = new ();
            _leoEcsInstaller.Install(_inputRoot.Input);
            _leoEcsInstaller.PlayerApi.RegisterPlayer(_playerAuthoring.Transform, _border, _playerAuthoring.Speed, _playerAuthoring.IFramesDuration);

            _pickupTrigger.Construct(_leoEcsInstaller.PickupApi);

            _gameUiBridge = new();
            GameTimeService gameTimeService = new();
            PoolManager poolManager = new();
            Wallet wallet = new(_gameConfig.StartCoinValues, _gameConfig.StartCrystalValues);
            Factory factory = new(poolManager, _playerAuthoring.Transform, _leoEcsInstaller.ProjectileApi, _leoEcsInstaller.ProjectileWeaponApi, _leoEcsInstaller.WeaponHitboxApi, _leoEcsInstaller.OrbitWeaponApi, _leoEcsInstaller.AxeApi, _leoEcsInstaller.LeoEnemyApi);
            EnemyDeathHandler enemyHandler = new(poolManager, _generatorData);
            EnemySpawnerController enemySpawnerController = new(_playerAuthoring.Transform, _generatorData, factory, _border);
            _upgradeSystem = new(_weaponLevelUpsData, _playerLevelUpsData, factory, _leoEcsInstaller.WeaponApi, _gameConfig, wallet, _leoEcsInstaller.PlayerApi, _playerAuthoring.Transform, _leoEcsInstaller.HudEcsApi);
            ProgressionSystem progressionSystem = new(_upgradeSystem, wallet, _config, _leoEcsInstaller.EnemySpawnerApi, _gameUiBridge, _leoEcsInstaller.HudEcsApi, gameTimeService);
            PlayerLifecycleService playerLifecycleService = new(_leoEcsInstaller.PlayerApi, _playerDeathView, _leoEcsInstaller.WeaponApi);
            GameManager gameManager = new(enemySpawnerController, progressionSystem, _upgradeSystem, wallet, poolManager, _leoEcsInstaller.EnemySpawnerApi, playerLifecycleService, _inputRoot.Input, _gameUiBridge, _leoEcsInstaller.GameRuntimeEcsApi);
            PlayerDeathService playerDeathService = new(playerLifecycleService, _playerDeathView, gameManager);
            _uiRoot.Construct(progressionSystem, _upgradeSystem, wallet, gameManager, _leoEcsInstaller.PlayerHealthView, _leoEcsInstaller.PlayerShieldView);

            _leoEcsInstaller.InstallSystems(wallet, enemyHandler, enemySpawnerController, playerDeathService, _gameUiBridge, progressionSystem);
        }

        private void Initialization()
        {
            _upgradeSystem.Init();
            _gameUiBridge.ShowMenu();
        }
    }
}