namespace Application
{
    public interface IPlayerReadModel
    {
        public int CurrentHealth { get; }
        public int MaxHealth { get; }
    }
}
