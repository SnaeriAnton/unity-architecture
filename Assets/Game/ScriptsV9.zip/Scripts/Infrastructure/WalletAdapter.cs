using System;
using Application;
using Domain;

namespace Infrastructure
{
    public class WalletAdapter : IWallet, IWalletReadModel
    {
        private readonly Wallet _wallet;

        public WalletAdapter(Wallet wallet) { _wallet = wallet; }

        public int Coins => _wallet.Coins;
        public int Crystals => _wallet.Crystals;

        public event Action CoinsChanged;
        public event Action CrystalsChanged;

        public void AddCoin() => _wallet.AddCoin();
        public void AddCrystal() => _wallet.AddCrystal();

        public bool TrySpendCoins(int value)
        {
            bool result = _wallet.TrySpendCoin(value);
            if (result) CoinsChanged?.Invoke();
            return result;
        }

        public bool TrySpendCrystals(int value)
        {
            bool result = _wallet.TrySpendCrystal(value);
            if (result) CrystalsChanged?.Invoke();
            return result;
        }
        
        public void Reset() => _wallet.Reset();
    }
}