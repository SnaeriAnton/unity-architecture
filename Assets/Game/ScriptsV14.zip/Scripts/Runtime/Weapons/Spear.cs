using System;
using Domain;
using UnityEngine;

namespace Runtime
{
    public class Spear : MonoBehaviour, IPoolable
    {
        private Action _onDespawned;
        private WeaponStats _stats;
        private Vector3 _direction;
        private float _liveTime;
        private int _currentStrength;

        public int PoolID { get; private set; }

        public void Init(WeaponStats stats, Vector3 direction)
        {
            _stats = stats;
            _direction = direction;
            _currentStrength = _stats.Strength;
            _liveTime = _stats.LifeTime;
        }

        private void Update()
        {
            transform.position = Vector3.MoveTowards(transform.position, transform.position + _direction, _stats.FlightSpeed * Time.deltaTime);

            _liveTime -= Time.deltaTime;

            if (_liveTime <= 0) _onDespawned.Invoke();
        }

        void IPoolable.OnDespawned() => gameObject.SetActive(false);

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.TryGetComponent(out EnemyBase enemy))
            {
                enemy.TakeDamage(_stats.Damage);
                _currentStrength--;

                if (_currentStrength == 0) _onDespawned.Invoke();
            }
        }

        void IPoolable.OnSpawned(int poolID, Action onDespawned)
        {
            PoolID = poolID;
            _onDespawned = onDespawned;
            gameObject.SetActive(true);
        }
    }
}