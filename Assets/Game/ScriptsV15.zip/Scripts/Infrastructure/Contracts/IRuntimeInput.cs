using System;
using UnityEngine;

namespace Infrastructure
{
    public interface IRuntimeInput
    {
        event Action<float, float> Move;
    }
}
