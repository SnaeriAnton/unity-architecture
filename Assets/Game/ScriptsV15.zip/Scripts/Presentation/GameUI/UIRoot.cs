using System.Collections.Generic;
using UnityEngine;
using Application;
using Infrastructure;
using UnityEngine.UI;

namespace Presentation
{
    public class UIRoot : MonoBehaviour
    {
        [SerializeField] private HUD _hud;
        [SerializeField] private LoseScreen _loseScreen;
        [SerializeField] private UpgradeWindow _upgradeWindow;
        [SerializeField] private MenuScreen _menuScreen;

        private Screen _currentScreen;
        private ProgressionService _progression;
        private GameSessionService _game;

        public HUD HUD => _hud;

        public void Construct(
            IReadOnlyDictionary<int, Sprite> upgradeIconDictionary,
            IReadOnlyDictionary<int, Sprite> currencyOfTypes,
            ProgressionService progression,
            UpgradeSystem upgradeStates,
            WalletService wallet,
            GameSessionService game,
            Player player,
            EnemyDeathHandler handler
        )
        {
            _game = game;
            _progression = progression;
            _loseScreen.Construct(game);
            _menuScreen.Construct(game);
            _upgradeWindow.Construct(upgradeIconDictionary, currencyOfTypes, progression, upgradeStates, wallet);
            _hud.Construct(player, wallet, progression, handler);

            _game.OnLost += ShowLose;
            _game.OnStartedGame += ShowHud;
            _game.OnRestartGame += ShowMenu;
            _game.OnResetValues += ResetScreens;
            _progression.OnReachedGoal += ShowUpgrade;
        }

        public void Dispose()
        {
            List<Button> buttons = new();

            _game.OnLost -= ShowLose;
            _game.OnStartedGame -= ShowHud;
            _game.OnRestartGame -= ShowMenu;
            _game.OnResetValues -= ResetScreens;
            _progression.OnReachedGoal -= ShowUpgrade;

            _hud.Dispose();
            _loseScreen.Dispose();
            _upgradeWindow.Dispose();
            _menuScreen.Dispose();

            buttons.AddRange(_hud.transform.GetComponentsInChildren<Button>());
            buttons.AddRange(_loseScreen.transform.GetComponentsInChildren<Button>());
            buttons.AddRange(_upgradeWindow.transform.GetComponentsInChildren<Button>());
            buttons.AddRange(_menuScreen.transform.GetComponentsInChildren<Button>());
            buttons.ForEach(b => b.onClick.RemoveAllListeners());
        }

        public void ShowMenu()
        {
            _currentScreen?.Hide();
            _currentScreen = _menuScreen;
            _currentScreen.Show();
        }

        public void ShowHud()
        {
            _currentScreen?.Hide();
            _currentScreen = _hud;
            _currentScreen.Show();
        }

        public void ShowLose()
        {
            _currentScreen?.Hide();
            _currentScreen = _loseScreen;
            _currentScreen.Show();
        }

        public void ShowUpgrade() => _upgradeWindow.Show();

        public void ResetScreens()
        {
            _hud.Reset();
            _loseScreen.Reset();
            _upgradeWindow.Reset();
            _menuScreen.Reset();
        }
    }
}